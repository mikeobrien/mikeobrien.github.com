﻿using StructureMap.Configuration.DSL.Expressions;
using StructureMapContrib.Pipeline;

namespace StructureMapContrib.Configuration.DSL.Expressions
{
    public static class CreatePluginFamilyExpressionExtensions
    {
        public static CreatePluginFamilyExpression<PLUGINTYPE> LifecycleStrategiesAre<PLUGINTYPE>(this CreatePluginFamilyExpression<PLUGINTYPE> expression, params ILifecycleStrategy[] strategies)
        {
            expression.LifecycleIs(new StrategicLifecycle(strategies));
            return expression;
        }
    }
}


