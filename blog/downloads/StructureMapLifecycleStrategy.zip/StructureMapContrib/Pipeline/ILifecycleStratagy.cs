﻿using StructureMap.Pipeline;

namespace StructureMapContrib.Pipeline
{
    public interface ILifecycleStrategy
    {
        bool IsValid();
        ILifecycle Lifecycle { get;}
    }
}


