﻿using System.ServiceModel;
using StructureMap.Pipeline;

namespace StructureMapContrib.Pipeline
{
    public class WcfOperationLifecycle : ILifecycle
    {
        public static readonly string ITEM_NAME = "STRUCTUREMAP-INSTANCES";

        public void EjectAll()
        {
            FindCache().DisposeAndClear();
        }

        public IObjectCache FindCache()
        {
            if (!OperationContext.Current.OutgoingMessageProperties.ContainsKey(ITEM_NAME))
                OperationContext.Current.OutgoingMessageProperties.Add(ITEM_NAME, new MainObjectCache());
            return (IObjectCache)OperationContext.Current.OutgoingMessageProperties[ITEM_NAME]; 
        }

        public string Scope { get { return "WcfOperationLifecycle"; } }

        public static bool HasContext()
        {
            return OperationContext.Current != null;
        }
    }
}


