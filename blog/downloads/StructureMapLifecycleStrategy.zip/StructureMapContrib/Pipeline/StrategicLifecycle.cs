﻿using System;
using System.Collections.Generic;
using System.Linq;
using StructureMap.Pipeline;

namespace StructureMapContrib.Pipeline
{
    public class StrategicLifecycle : ILifecycle 
    {
        private List<ILifecycleStrategy> _strategies;

        public StrategicLifecycle(params ILifecycleStrategy[] strategies)
        { _strategies = strategies; }

        public void Add(ILifecycleStrategy lifecycleStrategy)
        { _strategies.Add(lifecycleStrategy); }

        public void EjectAll()
        { ResolveLifecycle().EjectAll(); }

        public IObjectCache FindCache()
        { return ResolveLifecycle().FindCache(); }

        public string Scope
        { get { return "StrategicLifecycle"; } }

        private ILifecycle ResolveLifecycle()
        {
            var lifecycle = (from strategy in _strategies
                             where strategy.IsValid()
                             select strategy.Lifecycle).FirstOrDefault();
            if (lifecycle == null) throw 
                new Exception("Unable to find a suitable lifecycle Strategy.");
            return lifecycle;            
        }
    }
}


