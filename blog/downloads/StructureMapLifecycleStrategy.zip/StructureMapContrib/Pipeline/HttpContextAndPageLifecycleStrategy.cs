﻿using System.Web;
using System.Web.UI;
using StructureMap.Pipeline;

namespace StructureMapContrib.Pipeline
{
    public class HttpContextAndPageLifecycleStrategy : LifecycleStrategy
    {
        public HttpContextAndPageLifecycleStrategy() : base(
            () => HttpContextLifecycle.HasContext() && HttpContext.Current.Handler is Page, 
            () => new HttpContextLifecycle(), 
            c => ((Page)HttpContext.Current.Handler).Unload += ((s,e) => c.DisposeAndClear())) {}
    }
}


