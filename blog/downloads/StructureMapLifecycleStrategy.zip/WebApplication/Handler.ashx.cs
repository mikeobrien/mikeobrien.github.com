﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;
using Core;

namespace WebApplication
{
    public class Handler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            StringBuilder response = new StringBuilder();

            INumberGenerator numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            context.Response.ContentType = "text/plain";
            context.Response.Write(response.ToString());
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}