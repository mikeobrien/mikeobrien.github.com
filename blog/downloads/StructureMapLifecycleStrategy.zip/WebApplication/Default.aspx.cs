﻿using System;
using System.Text;
using System.Threading;
using Core;

namespace WebApplication
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            StringBuilder response = new StringBuilder();

            INumberGenerator numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            Output.Text = response.ToString();
        }
    }
}
