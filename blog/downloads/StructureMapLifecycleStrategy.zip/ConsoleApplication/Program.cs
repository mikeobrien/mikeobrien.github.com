﻿using System;
using System.Threading;
using Core;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            INumberGenerator numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            Console.WriteLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            Console.WriteLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                Console.WriteLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                Console.WriteLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            Console.WriteLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            Console.WriteLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
            {
                INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                Console.WriteLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                Console.WriteLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
            });
            Thread.Sleep(500);

            Console.ReadKey();
        }
    }
}
