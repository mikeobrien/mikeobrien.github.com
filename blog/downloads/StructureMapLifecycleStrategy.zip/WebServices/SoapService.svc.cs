﻿using System.ServiceModel;
using System.Text;
using System.Threading;
using Core;

namespace WebServices
{
    [ServiceContract]
    public interface ISoapService
    {
        [OperationContract]
        string GetData();
    }

    public class SoapService : ISoapService
    {
        public string GetData()
        {
            StringBuilder response = new StringBuilder();

            INumberGenerator numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
                                             {
                                                 INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                                                 response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                                                 newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                                                 response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
                                             });
            Thread.Sleep(500);

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            numberGenerator = Registry.Current.Resolve<INumberGenerator>();
            response.AppendLine(Diagnostics.DebugWrite(numberGenerator.Number));

            ThreadPool.QueueUserWorkItem(x =>
                                             {
                                                 INumberGenerator newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                                                 response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));

                                                 newNumberGenerator = Registry.Current.Resolve<INumberGenerator>();
                                                 response.AppendLine(Diagnostics.DebugWrite(newNumberGenerator.Number));
                                             });
            Thread.Sleep(500);
            return response.ToString();
        }
    }
}


