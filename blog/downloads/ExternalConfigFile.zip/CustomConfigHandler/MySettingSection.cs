using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CustomConfigHandler
{
    public class MySettingSection : ConfigurationSection 
    {
        private static ConfigurationPropertyCollection _Properties;
        private static ConfigurationProperty _SomeSetting;

        static MySettingSection()
        {
            _Properties = new ConfigurationPropertyCollection();
            _SomeSetting = new ConfigurationProperty("someSetting", typeof(MySettingElement), new MySettingElement());
            _Properties.Add(_SomeSetting);
        }

        public MySettingElement SomeSetting
        {
            get { return (MySettingElement)base[_SomeSetting]; }
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return _Properties;
            }
        }
    }
}
