using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CustomConfigHandler
{
    public class MySettingElement : ConfigurationElement 
    {
        private static ConfigurationPropertyCollection _Properties;
        private static ConfigurationProperty _SomeAttribute;

        static MySettingElement()
        {
            _Properties = new ConfigurationPropertyCollection();
            _SomeAttribute = new ConfigurationProperty("someAttribute", typeof(string), string.Empty, ConfigurationPropertyOptions.IsRequired & ConfigurationPropertyOptions.IsKey);
            _Properties.Add(_SomeAttribute);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return _Properties;
            }
        }

        public string SomeAttribute
        {
            get { return (string)base[_SomeAttribute]; }
        }
    }
}
