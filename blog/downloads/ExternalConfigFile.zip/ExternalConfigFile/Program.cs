using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using CustomConfigHandler;

namespace ExternalConfigFile
{
    class Program
    {
        static void Main(string[] args)
        {
            MySettingSection MySettings;

            MySettings = GetSettings("Settings1.config");
            Console.WriteLine("Settings1.config: " + MySettings.SomeSetting.SomeAttribute);

            MySettings = GetSettings("Settings2.config");
            Console.WriteLine("Settings2.config: " + MySettings.SomeSetting.SomeAttribute);

            Console.ReadKey();
        }

        static MySettingSection GetSettings(string ConfigFile)
        {
            ExeConfigurationFileMap FileMap = new ExeConfigurationFileMap();
            FileMap.ExeConfigFilename = ConfigFile;
            Configuration Manager = ConfigurationManager.OpenMappedExeConfiguration(FileMap, ConfigurationUserLevel.None);
            return (MySettingSection)Manager.GetSection("mySettings");
        }
    }
}
