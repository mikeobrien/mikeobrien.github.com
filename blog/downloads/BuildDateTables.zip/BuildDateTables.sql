/* 
Created by Mike O'Brien
www.mike-obrien.net
blog.mike-obrien.net
*/

DECLARE @StartDate datetime
DECLARE @EndDate datetime
DECLARE @Date datetime

SET @StartDate = '1/1/1900'
SET @EndDate = '1/1/2100'

/* Create Day Table */

SET @Date = @StartDate

CREATE TABLE Days (
Day datetime PRIMARY KEY CLUSTERED, 
ThisYearBegin datetime, 
NextYearBegin datetime,
ThisMonthBegin datetime, 
NextMonthBegin datetime,
NextDayBegin datetime)

WHILE (@Date <= @EndDate)
BEGIN

	INSERT INTO Days (
	Day,
	ThisYearBegin, 
	NextYearBegin,
	ThisMonthBegin, 
	NextMonthBegin,
	NextDayBegin
	) VALUES (
	@Date,
	CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(dayofyear, @Date)-1)*-1, @Date)))), 
	DATEADD(year, 1, CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(dayofyear, @Date)-1)*-1, @Date))))),
	CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(day, @Date)-1)*-1, @Date)))), 
	DATEADD(month, 1, CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(day, @Date)-1)*-1, @Date))))),
	DATEADD(day, 1, @Date)
	)

	SET @Date = DATEADD(day, 1, @Date)

END

CREATE NONCLUSTERED INDEX IX_Days_ThisYearBegin ON Days (ThisYearBegin)
CREATE NONCLUSTERED INDEX IX_Days_NextYearBegin ON Days (NextYearBegin)
CREATE NONCLUSTERED INDEX IX_Days_ThisMonthBegin ON Days (ThisMonthBegin)
CREATE NONCLUSTERED INDEX IX_Days_NextMonthBegin ON Days (NextMonthBegin)
CREATE NONCLUSTERED INDEX IX_Days_NextDayBegin ON Days (NextDayBegin)

/* Create Month Table */

SET @Date = @StartDate

CREATE TABLE Months (
Month datetime PRIMARY KEY CLUSTERED, 
ThisYearBegin datetime, 
NextYearBegin datetime,
NextMonthBegin datetime)

WHILE (@Date <= @EndDate)
BEGIN

	INSERT INTO Months (
	Month,
	ThisYearBegin, 
	NextYearBegin,
	NextMonthBegin
	) VALUES (
	@Date,
	CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(dayofyear, @Date)-1)*-1, @Date)))), 
	DATEADD(year, 1, CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(dayofyear, @Date)-1)*-1, @Date))))),
	DATEADD(month, 1, CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(day, @Date)-1)*-1, @Date)))))
	)

	SET @Date = DATEADD(month, 1, @Date)

END

CREATE NONCLUSTERED INDEX IX_Months_ThisYearBegin ON Months (ThisYearBegin)
CREATE NONCLUSTERED INDEX IX_Months_NextYearBegin ON Months (NextYearBegin)
CREATE NONCLUSTERED INDEX IX_Months_NextMonthBegin ON Months (NextMonthBegin)

/* Create Year Table */

SET @Date = @StartDate

CREATE TABLE Years (
Year datetime PRIMARY KEY CLUSTERED, 
NextYearBegin datetime)

WHILE (@Date <= @EndDate)
BEGIN

	INSERT INTO Years (
	Year,
	NextYearBegin
	) VALUES (
	@Date,
	DATEADD(year, 1, CONVERT(datetime, FLOOR(CONVERT(real, DATEADD(day, (DATEPART(dayofyear, @Date)-1)*-1, @Date)))))
	)

	SET @Date = DATEADD(year, 1, @Date)

END

CREATE NONCLUSTERED INDEX IX_Years_NextYearBegin ON Years (NextYearBegin)