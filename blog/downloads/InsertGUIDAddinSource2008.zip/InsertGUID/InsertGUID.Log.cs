using System;
using System.Collections.Generic;
using System.Text;

namespace InsertGUID
{
    public static class Log
    {
        public static void Write(string Message)
        {
            System.IO.File.AppendAllText(@"InsertGUID.log", string.Format("{0}\r\n", Message));
        }
    }
}
