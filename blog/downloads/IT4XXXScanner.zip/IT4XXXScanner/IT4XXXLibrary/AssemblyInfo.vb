Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("IT4600 Library")> 
<Assembly: AssemblyDescription("IT4600 2D Scanner Library")> 
<Assembly: AssemblyCompany("mike-obrien.net")> 
<Assembly: AssemblyProduct("IT4600Library")> 
<Assembly: AssemblyCopyright("Copyright � 2006 Michael P. O'Brien")> 
<Assembly: AssemblyTrademark("IT4600Library")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("D4543B8B-EA95-4BF3-8079-18B44BB98165")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.4")> 
