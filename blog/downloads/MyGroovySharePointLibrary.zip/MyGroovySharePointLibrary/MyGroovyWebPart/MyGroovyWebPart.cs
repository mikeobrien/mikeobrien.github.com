﻿using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace MyGroovyWebPart
{
    [Guid("cc2a1b52-324a-4a20-bca8-0d512f8348b4")]
    public class MyGroovyWebPart : 
        System.Web.UI.WebControls.WebParts.WebPart
    {
        public MyGroovyWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }

        protected override void CreateChildControls()
        {
            string userControl = "/UserControls/MyGroovyUserControl.ascx";
            try
            {
                Controls.Add(this.Page.LoadControl(userControl));
            }
            catch (Exception exception)
            {
                string message = string.Format("{0} failed to load: {1}", 
                    userControl,
                    exception.Message);
                Controls.Add(new LiteralControl(message));
            }
        }
    }
}
