using System;
using System.Collections.Generic;
using System.Text;

namespace WiXHelper
{
    public static class Log
    {
        public static void Write(string Message)
        {
            System.IO.File.AppendAllText(@"WiXHelper.log", string.Format("{0}\r\n", Message));
        }
    }
}
